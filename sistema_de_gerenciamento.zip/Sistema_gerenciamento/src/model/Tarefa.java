package model;

import java.time.LocalDate;

public class Tarefa {
    private Long id;
    private String titulo;
    private String descricao;
    private Projeto projeto;
    private Usuario responsavel;
    private Categoria categoria;
    private Prioridade prioridade;
    private Status status;
    private LocalDate criacao;
    private LocalDate prazo;

    public Tarefa(Long id, String titulo, String descricao, Projeto projeto,
                  Usuario responsavel, Categoria categoria,
                  Prioridade prioridade, Status status, LocalDate prazo) {

        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.projeto = projeto;
        this.responsavel = responsavel;
        this.categoria = categoria;
        this.prioridade = prioridade;
        this.status = status;
        this.criacao = LocalDate.now();
        this.prazo = prazo;
    }

}
