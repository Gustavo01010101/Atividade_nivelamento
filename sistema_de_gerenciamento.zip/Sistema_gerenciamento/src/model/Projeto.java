package model;

public class Projeto {
    private Long id;
    private String nome;
    private String descricao;

    public Projeto(Long id, String nome, String descricao) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
    }

}
