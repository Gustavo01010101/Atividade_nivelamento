from datetime import date
from modelo.modelos import Status, Prioridade

def menu_principal(usuario_repo, projeto_repo, categoria_repo, tarefa_service):
    while True:
        print("\n--- MENU PRINCIPAL ---")
        print("1 - Usuários")
        print("2 - Projetos")
        print("3 - Categorias")
        print("4 - Tarefas")
        print("5 - Relatórios")
        print("0 - Sair")
        opc = input("Escolha: ")

        if opc == "1":
            menu_usuarios(usuario_repo)
        elif opc == "2":
            menu_projetos(projeto_repo)
        elif opc == "3":
            menu_categorias(categoria_repo)
        elif opc == "4":
            menu_tarefas(tarefa_service)
        elif opc == "5":
            menu_relatorios(tarefa_service)
        elif opc == "0":
            break

def menu_usuarios(usuario_repo):
    while True:
        print("\n--- USUÁRIOS ---")
        print("1 - Adicionar")
        print("2 - Listar")
        print("0 - Voltar")
        opc = input("Escolha: ")

        if opc == "1":
            nome = input("Nome: ")
            email = input("Email: ")
            usuario_repo.adicionar(nome, email)
            print("Usuário adicionado com sucesso!")
        elif opc == "2":
            for u in usuario_repo.listar():
                u.exibir()
        elif opc == "0":
            break

def menu_projetos(projeto_repo):
    while True:
        print("\n--- PROJETOS ---")
        print("1 - Adicionar")
        print("2 - Listar")
        print("0 - Voltar")
        opc = input("Escolha: ")

        if opc == "1":
            nome = input("Nome: ")
            descricao = input("Descrição: ")
            projeto_repo.adicionar(nome, descricao)
            print("Projeto criado!")
        elif opc == "2":
            for p in projeto_repo.listar():
                p.exibir()
        elif opc == "0":
            break

def menu_categorias(categoria_repo):
    while True:
        print("\n--- CATEGORIAS ---")
        print("1 - Adicionar")
        print("2 - Listar")
        print("0 - Voltar")
        opc = input("Escolha: ")

        if opc == "1":
            nome = input("Nome: ")
            categoria_repo.adicionar(nome)
            print("Categoria criada!")
        elif opc == "2":
            for c in categoria_repo.listar():
                c.exibir()
        elif opc == "0":
            break

def menu_tarefas(tarefa_service):
    while True:
        print("\n--- TAREFAS ---")
        print("1 - Adicionar")
        print("2 - Listar")
        print("0 - Voltar")
        opc = input("Escolha: ")

        if opc == "1":
            try:
                titulo = input("Título: ")
                descricao = input("Descrição: ")
                projeto_id = int(input("ID do projeto: "))
                responsavel_id = int(input("ID do responsável: "))
                categoria_id = int(input("ID da categoria: "))
                prioridade = Prioridade[int(input("Prioridade (1=Alta, 2=Média, 3=Baixa): "))]
                status = Status[int(input("Status (1=A Fazer, 2=Fazendo, 3=Feito): "))]
                prazo = date.fromisoformat(input("Prazo (AAAA-MM-DD): "))

                tarefa_service.criar_tarefa(titulo, descricao, projeto_id, responsavel_id,
                                            categoria_id, prioridade, status, prazo)
                print("Tarefa criada!")
            except Exception as e:
                print("Erro:", e)
        elif opc == "2":
            for t in tarefa_service.tarefa_repo.listar():
                t.exibir()
        elif opc == "0":
            break

def menu_relatorios(tarefa_service):
    print("\n--- RELATÓRIOS ---")
    print("\nTarefas por Status:")
    for s, tarefas in tarefa_service.tarefas_por_status().items():
        print(f"{s.name}: {len(tarefas)} tarefa(s)")
        for t in tarefas:
            print(f"  - {t.titulo}")

    print("\nTarefas Vencidas:")
    for t in tarefa_service.tarefas_vencidas():
        print(f"  - {t.titulo} (prazo: {t.prazo})")

    print("\nResumo por Usuário:")
    for nome, qtd in tarefa_service.resumo_por_usuario().items():
        print(f"{nome}: {qtd} tarefa(s)")

    print("\nResumo por Projeto:")
    for nome, qtd in tarefa_service.resumo_por_projeto().items():
        print(f"{nome}: {qtd} tarefa(s)")
