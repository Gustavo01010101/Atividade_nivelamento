from repositorio.repositorios import UsuarioRepositorio, ProjetoRepositorio, CategoriaRepositorio, TarefaRepositorio
from servico.servicos import TarefaService
from ui.menu import menu_principal

def main():
    usuario_repo = UsuarioRepositorio()
    projeto_repo = ProjetoRepositorio()
    categoria_repo = CategoriaRepositorio()
    tarefa_repo = TarefaRepositorio()
    tarefa_service = TarefaService(tarefa_repo, usuario_repo, projeto_repo, categoria_repo)
    print("=== SISTEMA DE GERENCIAMENTO DE TAREFAS ===")
    menu_principal(usuario_repo, projeto_repo, categoria_repo, tarefa_service)

if __name__ == "__main__":
    main()
