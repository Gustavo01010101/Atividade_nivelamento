from modelo.modelos import Usuario, Projeto, Categoria, Tarefa

class BaseRepositorio:
    def __init__(self):
        self._itens = []
        self._proximo_id = 1

    def gerar_id(self):
        id_atual = self._proximo_id
        self._proximo_id += 1
        return id_atual

class UsuarioRepositorio(BaseRepositorio):
    def adicionar(self, nome, email):
        usuario = Usuario(self.gerar_id(), nome, email)
        self._itens.append(usuario)
        return usuario

    def listar(self):
        return self._itens

    def buscar(self, id):
        for u in self._itens:
            if u.id == id:
                return u
        return None

    def remover(self, id):
        u = self.buscar(id)
        if u:
            self._itens.remove(u)
            return True
        return False

class ProjetoRepositorio(BaseRepositorio):
    def adicionar(self, nome, descricao):
        projeto = Projeto(self.gerar_id(), nome, descricao)
        self._itens.append(projeto)
        return projeto

    def listar(self):
        return self._itens

    def buscar(self, id):
        for p in self._itens:
            if p.id == id:
                return p
        return None

    def remover(self, id):
        p = self.buscar(id)
        if p:
            self._itens.remove(p)
            return True
        return False

class CategoriaRepositorio(BaseRepositorio):
    def adicionar(self, nome):
        categoria = Categoria(self.gerar_id(), nome)
        self._itens.append(categoria)
        return categoria

    def listar(self):
        return self._itens

    def buscar(self, id):
        for c in self._itens:
            if c.id == id:
                return c
        return None

    def remover(self, id):
        c = self.buscar(id)
        if c:
            self._itens.remove(c)
            return True
        return False

class TarefaRepositorio(BaseRepositorio):
    def adicionar(self, titulo, descricao, projeto_id, responsavel_id, categoria_id,
                  prioridade, status, criacao, prazo):
        tarefa = Tarefa(self.gerar_id(), titulo, descricao, projeto_id, responsavel_id,
                        categoria_id, prioridade, status, criacao, prazo)
        self._itens.append(tarefa)
        return tarefa

    def listar(self):
        return self._itens

    def buscar(self, id):
        for t in self._itens:
            if t.id == id:
                return t
        return None

    def remover(self, id):
        t = self.buscar(id)
        if t:
            self._itens.remove(t)
            return True
        return False
