from enum import Enum
from datetime import date

class Usuario:
    def __init__(self, id, nome, email):
        self.id = id
        self.nome = nome
        self.email = email

    def exibir(self):
        print(f"{self.id} - {self.nome} ({self.email})")

class Projeto:
    def __init__(self, id, nome, descricao):
        self.id = id
        self.nome = nome
        self.descricao = descricao

    def exibir(self):
        print(f"{self.id} - {self.nome}: {self.descricao}")

class Categoria:
    def __init__(self, id, nome):
        self.id = id
        self.nome = nome

    def exibir(self):
        print(f"{self.id} - {self.nome}")

class Status(Enum):
    A_FAZER = 1
    FAZENDO = 2
    FEITO = 3

class Prioridade(Enum):
    ALTA = 1
    MEDIA = 2
    BAIXA = 3

class Tarefa:
    def __init__(self, id, titulo, descricao, projeto_id, responsavel_id, categoria_id,
                 prioridade, status, criacao, prazo):
        self.id = id
        self.titulo = titulo
        self.descricao = descricao
        self.projeto_id = projeto_id
        self.responsavel_id = responsavel_id
        self.categoria_id = categoria_id
        self.prioridade = prioridade
        self.status = status
        self.criacao = criacao
        self.prazo = prazo

    def exibir(self):
        print(f"""
        ID: {self.id}
        Título: {self.titulo}
        Descrição: {self.descricao}
        Projeto ID: {self.projeto_id}
        Responsável ID: {self.responsavel_id}
        Categoria ID: {self.categoria_id}
        Prioridade: {self.prioridade.name}
        Status: {self.status.name}
        Criação: {self.criacao}
        Prazo: {self.prazo}
        """)
