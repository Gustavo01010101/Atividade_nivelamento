from datetime import date
from modelo.modelos import Status

class TarefaService:
    def __init__(self, tarefa_repo, usuario_repo, projeto_repo, categoria_repo):
        self.tarefa_repo = tarefa_repo
        self.usuario_repo = usuario_repo
        self.projeto_repo = projeto_repo
        self.categoria_repo = categoria_repo

    def criar_tarefa(self, titulo, descricao, projeto_id, responsavel_id, categoria_id,
                     prioridade, status, prazo):
        if not titulo:
            raise ValueError("Título obrigatório.")
        if not self.projeto_repo.buscar(projeto_id):
            raise ValueError("Projeto inválido.")
        if not self.usuario_repo.buscar(responsavel_id):
            raise ValueError("Responsável inválido.")
        criacao = date.today()
        return self.tarefa_repo.adicionar(titulo, descricao, projeto_id, responsavel_id,
                                          categoria_id, prioridade, status, criacao, prazo)

    def tarefas_por_status(self):
        resultado = {s: [] for s in Status}
        for t in self.tarefa_repo.listar():
            resultado[t.status].append(t)
        return resultado

    def tarefas_vencidas(self):
        hoje = date.today()
        return [t for t in self.tarefa_repo.listar() if t.prazo < hoje]

    def resumo_por_usuario(self):
        resumo = {}
        for u in self.usuario_repo.listar():
            total = len([t for t in self.tarefa_repo.listar() if t.responsavel_id == u.id])
            resumo[u.nome] = total
        return resumo

    def resumo_por_projeto(self):
        resumo = {}
        for p in self.projeto_repo.listar():
            total = len([t for t in self.tarefa_repo.listar() if t.projeto_id == p.id])
            resumo[p.nome] = total
        return resumo
